﻿namespace Dem0n13.SocketServer
{
    public interface ILogicServer
    {
        string GetResponse(string request);
    }
}
